﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    internal abstract class BigDataLoader
    {
        public void ETL()
        {
            Extracting();
            Transforming();
            Loading();
        }

      
        public abstract void Extracting();
        public abstract void Transforming();
        public abstract void  Loading();

    }
}
