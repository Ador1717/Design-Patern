﻿namespace assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }
        void Start()
        {
            BatchProcessor processor = new BatchProcessor();

            processor.AddBigDataLoader(new CallDataLoader());
            processor.AddBigDataLoader(new TwitterDataLoader());
            processor.AddBigDataLoader(new SensorDataLoader());

            processor.process();
        }
    }
}