﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    internal class BatchProcessor //: BigDataLoader
    {
        private List<BigDataLoader> bigDataLoaders = new List<BigDataLoader>();

        public void AddBigDataLoader(BigDataLoader bigDataLoader)
        {
           this.bigDataLoaders.Add(bigDataLoader);
        }
        public void process()
        {
            foreach (BigDataLoader bigDataLoader in bigDataLoaders)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("[ETL-proces started]");
                Console.ResetColor();
                bigDataLoader.ETL();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("[ETL-proces finished]");
                Console.ResetColor();
                Console.WriteLine();
               
            }
        }
    }
}
