﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    internal class SensorDataLoader : BigDataLoader
    {
        public override void Extracting()
        {
            Console.WriteLine("extracting sensor data...");
        }

        public override void Loading()
        {
            Console.WriteLine("loading transformed data...");
        }

        public override void Transforming()
        {
            Console.WriteLine("transforming sensor data...");
        }
    }
}
