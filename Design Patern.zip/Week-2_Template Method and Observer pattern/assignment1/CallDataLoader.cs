﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    internal class CallDataLoader : BigDataLoader
    {
        public void ETC()
        {
            Extracting();
            Loading();
            Transforming();
        }
        public override void Extracting()
        {
            Console.WriteLine("extracting call data...");
        }

        public override void Loading()
        {
           Console.WriteLine("loading transformed data...");
        }

        public override void Transforming()
        {
            Console.WriteLine("transforming call data...");
        }
    }
}
