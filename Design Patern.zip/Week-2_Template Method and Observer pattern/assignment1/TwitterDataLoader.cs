﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    internal class TwitterDataLoader : BigDataLoader
    {
        public override void Extracting()
        {
            Console.WriteLine("extracting twitter data...");
        }

        public override void Loading()
        {
            Console.WriteLine("loading transformed data...");
        }

        public override void Transforming()
        {
            Console.WriteLine("transforming twitter data...");
        }
    }
}
