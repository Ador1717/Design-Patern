﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3
{
    internal class MP3Player : IObservable
    {
        public Song CurrentSong { get; private set; }

        private List<IObserver> servers = new List<IObserver>();
        private List<Song> songs;
        private Random random = new Random();

        public MP3Player()
        {

            TimeSpan duration1 = new TimeSpan(0, 5, 24);
            TimeSpan duration2 = new TimeSpan(0, 5, 39);
            TimeSpan duration3 = new TimeSpan(0, 6, 29);
            TimeSpan duration4 = new TimeSpan(0, 3, 31);
            songs = new List<Song>
            {
            new Song("Papillon", "Editors", duration1),
            new Song ( "Wish You Were Here",  "Pink Floyd",  duration2 ),
            new Song ("Dazed and Confused",  "Led Zeppelin", duration3),
            new Song ( "Billionaire","Bruno Mars", duration4)
            };
        }
        public void NextSong()
        {
            int index = random.Next(songs.Count);
            CurrentSong = songs[index];
            NotifyObservers();
        }
        private void NotifyObservers()
        {
            foreach (IObserver observer in servers)
            {
                observer.Update(CurrentSong);
            }
        }

        public void AddObserver(IObserver observer)
        {
            servers.Add(observer);
        }

        public void RemoveObserver(IObserver observer)
        {
            servers.Remove(observer);
        }
    }
}
