﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
   
    internal class ArrayStack : IStack
    {
        public int[] stack;
        public int top;

        public ArrayStack(int maxSize)
        {
            stack = new int[maxSize];
            top = 0;
        }
        public void Push(int value)
        {
            if (top >= stack.Length)
            {
                throw new InvalidOperationException("Stack is full.");
            }
            stack[++top] = value;
        }
        public int Pop()
        {
            if (top < 0)
            {
                throw new InvalidCastException("Stack is empty.");
            }
            return stack[top--];
        }
        public bool Contains(int value)
        {
            for (int i = 0; i <= top; i++)
            {
                if (stack[i].Equals(value))
                {
                    return true;
                }
            }
            return false;
        }
       
        public int Count => top ;
        public bool IsEmpty => top == 0;
        
    }
}
