﻿namespace assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }
        void Start()
        {
            IStack myStack = new ArrayStack(50);
            AddValues(myStack);
            CheckValues(myStack);
            ProcessValues(myStack);
        }
        void AddValues(IStack stack)
        {
            Random random = new Random();
            for (int i = 0; i < 5; i++)
            {
                int value = random.Next(0, 100);
                stack.Push(value);
                Console.WriteLine($"pushed {value,2}, new count: {stack.Count} ");
            }
            Console.WriteLine();
        }
        void CheckValues(IStack stack)
        {
            while (true)
            {
                Console.Write("Enter a number: ");
                int input = int.Parse(Console.ReadLine());
                if (input == -1)
                {
                    break;
                }

                bool contains = stack.Contains(input);
                if (contains)
                {
                    Console.WriteLine($"stack contains value {input}");
                }
                else
                {
                    Console.WriteLine($"stack does not contain value {input}");
                }
              
            }
            Console.WriteLine();
        }
        void ProcessValues(IStack stack)
        {
            while (!stack.IsEmpty)
            {
                int value = stack.Pop();
                Console.WriteLine($"popped {value}, new count: {stack.Count}");
            }
        }
    }
    
}
