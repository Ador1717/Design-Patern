﻿namespace assignment2
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Program program = new Program();
            program.Start();
        }
        void Start()
        {
            IPencil pencil = new Pencil(20);
            IPencilSharpener sharpener = new PencilSharpener();

            while (true)
            {
                Console.Write("Enter a word: ");
                string message = Console.ReadLine();

                if (message == "stop")
                {
                    break;
                }

                if (message == "sharpen")
                {
                    sharpener.Sharpen(pencil);
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("Sharpening the pencil...");
                    Console.ResetColor();   
                    continue;
                }
                Console.ForegroundColor = ConsoleColor.Green;
                pencil.Write(message);
                Console.ResetColor();
            }
            Console.WriteLine();
            Console.WriteLine("end of the program...");

        }
    }
}