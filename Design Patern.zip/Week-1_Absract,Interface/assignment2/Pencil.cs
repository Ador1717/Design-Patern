﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    internal class Pencil : IPencil
    {
        private int maxToWrite; // number of characters to write with a sharpened pencil
        private int nrOfCharsWritten; // number of written characters

        public Pencil(int maxToWrite)
        {
            this.maxToWrite = maxToWrite;
            nrOfCharsWritten = 0;
        }

        public bool CanWrite => nrOfCharsWritten < maxToWrite;

        public void AfterSharpening()
        {
            nrOfCharsWritten = 0;
        }

        public void Write(string message)
        {
            foreach (char c in message)
            {
                if (!CanWrite)
                {
                    Console.Write('#');
                }
                else
                {
                    Console.Write(c);
                    nrOfCharsWritten++;
                }
            }
            Console.WriteLine();
        }
    }
}
