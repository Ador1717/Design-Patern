﻿namespace assignment2
{
    internal class Program
    {
        private const int AmountInMachine = 2000;

        static void Main(string[] args)
        {
            Program program = new Program();
            program.start();
        }
        public void start()
        {
            ATMMachine machine = new ATMMachine(AmountInMachine);
            string command;
            while (true)
            {
                Console.Write("Please enter your command: ");
                Console.ForegroundColor = ConsoleColor.Green;
                command = Console.ReadLine();
                Console.ResetColor();
                switch (command)
                {
                    case "insert card":
                        machine.InsertCard();
                        break;
                    case "reject card":
                        machine.RejectCard();
                        break;
                    case "enter pincode":
                        Console.Write("Please enter your pincode: ");
                        int pin = Convert.ToInt32(Console.ReadLine());
                        machine.EnterPincode(pin);
                        break;
                    case "withdraw cash":
                        Console.Write("Please enter the amount of cash: ");
                        int amount = Convert.ToInt32(Console.ReadLine());
                        machine.WithdrawCash(amount);
                       // machine.RejectCard();
                        break;
                    case "stop":
                        return;
                    default:
                        Console.WriteLine("entered unknown command");
                        break;
                }
                Console.WriteLine();
            }
        }
    }
}