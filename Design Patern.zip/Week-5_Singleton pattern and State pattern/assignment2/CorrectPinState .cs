﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    public class CorrectPinState : IATMState
    {
        private ATMMachine machine;

        public CorrectPinState(ATMMachine machine)
        {
            this.machine = machine;
        }
        public void EnterPincode(int pincode)
        {
            Console.WriteLine("Pincode is already entered");
        }

        public void InsertCard()
        {
            Console.WriteLine("A card has been inserted already");
        }

        public void RejectCard()
        {
            Console.WriteLine("Your card has been rejected");
        }

        public void WithdrawCash(int cash)
        {
            if (cash > machine.AmountInMachine)
            {
                Console.WriteLine("Not enough cash available in machine");
                machine.SetMachineState(machine.GetNoCashState());
                Console.WriteLine("Your card has been rejected");
            }
            else
            {
                machine.SetAmountInMachine(machine.AmountInMachine - cash);
                Console.WriteLine($"{cash} withdrawn from machine");
                Console.WriteLine("Your card has been rejected");
                machine.SetMachineState(machine.GetNoCardState());
            }
        }
    }
}
