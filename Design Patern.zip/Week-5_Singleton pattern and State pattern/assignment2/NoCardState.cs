﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    public class NoCardState : IATMState
    {
        private ATMMachine machine;
        public NoCardState(ATMMachine machine)
        {
            this.machine = machine; 
        }

        public void InsertCard()
        {
            Console.WriteLine("Card has been inserted");
            machine.SetMachineState(machine.GetCardPresentState());
        }

        public void RejectCard()
        { 
            Console.WriteLine("No card to eject"); 
        }

        public void EnterPincode(int pincode) 
        { 
            Console.WriteLine("No card present"); 
        }

        public void WithdrawCash(int cash) 
        { 
            Console.WriteLine("Insert card first"); 
        }
    }
}
