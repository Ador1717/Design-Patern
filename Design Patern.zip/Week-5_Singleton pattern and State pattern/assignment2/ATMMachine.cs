﻿using assignment2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    public class ATMMachine 
    {
        public int AmountInMachine { get; set; }
        private IATMState currentState;
        private IATMState cardPresent;
        private IATMState correctPinCode;
        private IATMState noCard;
        private IATMState noCash;

        public ATMMachine(int amountInMachine)
        {
            this.AmountInMachine = amountInMachine;
            cardPresent = new CardPresentState(this);
            correctPinCode = new CorrectPinState(this);
            noCard = new NoCardState(this);
            noCash = new NoCashState(this);
            currentState = noCard;
        }
        public void SetMachineState(IATMState state)
        {
            this.currentState = state;
        }
        public void SetAmountInMachine(int amount)
        {
            this.AmountInMachine = amount;
        }

        public void InsertCard()
        {
            currentState.InsertCard();
        }

        public void RejectCard()
        {
            currentState.RejectCard();
        }

        public void EnterPincode(int pincode)
        {
            currentState.EnterPincode(pincode);
        }

        public void WithdrawCash(int cash)
        {
            currentState.WithdrawCash(cash);
        }
        public IATMState GetNoCardState() 
        {
            return noCard; 
        }
        public IATMState GetCardPresentState()
        { 
            return cardPresent ;
        }
        public IATMState GetCorrectPinState()
        
        {
            return correctPinCode; 
        }
        public IATMState GetNoCashState()
        { 
            return noCash; 
        }
    }
}
