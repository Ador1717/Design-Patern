﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    public class MainSystem
    {
        private SubSystem subSystem;
        public MainSystem()
        {
            subSystem = new SubSystem();
        }

        public void DoSomeMainWork()
        {
            Logger.GetInstance.Log("MainSystem", "doing some main work");
            subSystem.DoSomeWork();
            subSystem.DoSomeMoreWork();


        }
    }
}
