﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment1
{
    public class Logger
    {
        private int numberOfLines;
        private static Logger uniqueInstance;

        private Logger()
        {
        }
        public static Logger GetInstance
        {
            get
            { 
                if (uniqueInstance == null)
                {
                     uniqueInstance = new Logger();
                }
                 return uniqueInstance;
            }
        }
        public void Log(string system, string message)
        {
            numberOfLines++;
            Console.WriteLine($"{numberOfLines} - [{system}] {message}");
        }
    }
}
