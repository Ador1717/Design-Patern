﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Term4_Week3
{
    internal interface ITrainDisplay
    {
        void Update(TrainStation CurrentStation);
        //void Update();
    }
}
