namespace Term4_Week3
{
    internal partial class Form1 : Form
    {
        TrainController controller;
        TrainJourney journey;


        public Form1(TrainJourney trainJourney, TrainController controller)
        {
            InitializeComponent();
            journey = trainJourney;
            this.controller = controller;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
                
        }
    
        private void button1_Click(object sender, EventArgs e)
        {
            controller.Next();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ITrainDisplay newDisplay = new Form2(journey);
            journey.AddObserver(newDisplay);
            (newDisplay as Form).Show();    
        }
    }
}