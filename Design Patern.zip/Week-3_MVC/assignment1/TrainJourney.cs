﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Term4_Week3
{
    internal class TrainJourney : ITrainJourney
    {
        public TrainStation CurrentStation { get; set; }
        public List<TrainStation> Stations { get; set; }

        public TrainStation currentStation { get { return CurrentStation; } }

        public List<ITrainDisplay> trainDisplays = new List<ITrainDisplay>();
        public TrainJourney()
        {
            Stations = new List<TrainStation>();
        }

        public void AddObserver(ITrainDisplay Observer)
        {
            trainDisplays.Add(Observer);
        }
        public void RemoveObserver(ITrainDisplay Observer)
        {
            trainDisplays.Remove(Observer);
        }
        private void NotifyStatioObserver()
        {
            foreach (ITrainDisplay Observer in trainDisplays)
            {
                Observer.Update(this.CurrentStation);
            }
        }
        public bool Forward = true;
        public void Next()
        {
            
            int index = Stations.IndexOf(CurrentStation);
            if (index < Stations.Count - 1)
            {
                CurrentStation = Stations[index + 1];
            }
            else
            {
                CurrentStation = Stations[0];
            }
            NotifyStatioObserver();
        }

    }
}
