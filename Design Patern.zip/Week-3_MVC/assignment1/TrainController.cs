﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Term4_Week3
{
    internal class TrainController : ITrainController
    {
        
        private ITrainJourney trainJourney;
        public TrainController(ITrainJourney trainJourney)
        {
            this.trainJourney = trainJourney;
        }

        public void Next()
        {
            trainJourney.Next();
        }
    }
}
