﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Term4_Week3
{
    internal class TrainStation
    {
        public string Name { get; set; }
        public string ArrivalTrack { get; set; }

        public TrainStation(string name, string arrivalTrack)
        {
            Name = name;
            ArrivalTrack = arrivalTrack;
        }
    }
}
