namespace Term4_Week3
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            TrainJourney journey = new TrainJourney();
            TrainStation station1 = new TrainStation("Leiden", "4b");
            TrainStation station2 = new TrainStation("Haarlem", "6");
            TrainStation station3 = new TrainStation("Overven", "2");

            journey.Stations.Add(station1);
            journey.Stations.Add(station2);
            journey.Stations.Add(station3);

           journey.CurrentStation = station1;
            // Create train stations

            TrainController controller = new TrainController(journey);
            Application.Run(new Form1(journey, controller));

        }
    }
}