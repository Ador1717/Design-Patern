﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConwayGameOfLife
{
    public class StandardLifeBehaviour : ILifeBehaviour
    {
        public bool CellShouldLive(bool livingCell, int neighbourCount)
        {
            if (!livingCell && neighbourCount == 3)
                return true;

            if (livingCell && (neighbourCount == 2 || neighbourCount == 3))
                return true;

            return false;
        }
    }
}
