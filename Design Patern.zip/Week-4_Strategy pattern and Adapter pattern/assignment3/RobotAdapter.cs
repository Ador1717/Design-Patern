﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3
{
    internal class RobotAdapter : IAttacker
    {
        private Robot robot;

        public RobotAdapter(Robot robot)
        {
            this.robot = robot;
        }

        public string Driver
        {
            get { return robot.Person; }
            set { robot.Person = value; }
        }



        public void AssignDriver(string driver)
        {
            robot.MoveByPerson(driver);
        }

        public void DriveForward()
        {
            robot.WalkForWard();
        }

        public void UseWeapon()
        {
            robot.BashWithHands();
        }
    }
}
