﻿namespace assignment3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();
            program.Start();
        }
        void Start()
        {
            Tank tank1= new Tank();
            tank1.AssignDriver("Frank");

            Robot robot1= new Robot();
            robot1.MoveByPerson("Mark");

            List<IAttacker> attackers = new List<IAttacker>();
            attackers.Add(tank1);
            attackers.Add(new RobotAdapter(robot1));

            foreach (IAttacker attacker in attackers)
            {
                Console.WriteLine();
                Console.WriteLine($"Driver of attacker: {attacker.Driver}");
                attacker.DriveForward();
                attacker.UseWeapon();
            }
        }
    }
}