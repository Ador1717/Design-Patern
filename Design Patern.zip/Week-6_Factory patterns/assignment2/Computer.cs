﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    public class Computer
    {
        public IProcessor Processor { get; set; }
        public IHardDisk Disk { get; set; }
        public IMonitor Monitor { get; set; }

        public Computer(IHardDisk disk, IProcessor processor, IMonitor monitor)
        {
            Disk = disk;
            Processor = processor;
            Monitor = monitor;
        }
        public void Test()
        {
            Processor.PerformAction();
            Disk.StoreData();
            Monitor.Display();
        }
    }
}
