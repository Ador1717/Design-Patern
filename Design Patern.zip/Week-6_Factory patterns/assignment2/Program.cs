﻿namespace assignment2
{
    internal class Program
    {
        private static  void Main(string[] args)
        {
            Program program = new Program();
            program.start();
        }
        private void start()
        {
            Console.WriteLine("[shop creating expensive computers]");
            ExpensiveFactory expensiveFactory = new ExpensiveFactory();
            ComputerShop expensiveStore = new ComputerShop(expensiveFactory);
            Computer expensiveComputer = expensiveStore.CreateComputer();
            expensiveComputer.Test();
            Console.WriteLine();
            Console.WriteLine("[shop creating cheap computers]");
            CheapFactory cheapFactory = new CheapFactory();
            ComputerShop cheapStore = new ComputerShop(cheapFactory);
            Computer cheapComputer = cheapStore.CreateComputer();
            cheapComputer.Test();
        }
    }
}