﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    public class ExpensiveFactory : ComputerFactory
    {
        public override IMonitor NewMonitor()
        {
            return new ExpensiveMonitor();
        }
        public override IProcessor NewProcessor()
        {
            return new ExpensiveProcessor();
        }
        public override IHardDisk NewDisk()
        {
            return new ExpensiveHardDisk();
        }
      
    }
}
