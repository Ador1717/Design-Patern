﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    public class CheapFactory : ComputerFactory
    {
        public override IProcessor NewProcessor()
        {
            return new CheapProcessor();
        }

        public override IHardDisk NewDisk()
        {
            return new CheapHardDisk();
        }

        public override IMonitor NewMonitor()
        {
            return new CheapMonitor();
        }
    }
}
