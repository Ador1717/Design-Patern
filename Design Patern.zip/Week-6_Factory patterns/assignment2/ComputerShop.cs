﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment2
{
    public class ComputerShop
    {
        private ComputerFactory factory { get; }
        public ComputerShop(ComputerFactory factory)
        {
            this.factory = factory;
        }
        public Computer CreateComputer()
        {
            IProcessor processor = factory.NewProcessor();
            IHardDisk disk = factory.NewDisk();
            IMonitor monitor = factory.NewMonitor();

            Computer computer = new Computer(disk, processor, monitor);
            return computer;
        }
    }
}
