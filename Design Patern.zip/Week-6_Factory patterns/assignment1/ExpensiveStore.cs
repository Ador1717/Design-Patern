﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace assignment1
{
    public class ExpensiveStore : ComputerShop
    {
        public override IProcessor NewProcessor()
        {
            return new ExpensiveProcessor();
        }
       
        public override IMonitor NewMonitor()
        {
            return new ExpensiveMonitor();
        }
        public override IHardDisk NewDisk()
        {
            return new ExpensiveHardDisk();
        }

    }
}
