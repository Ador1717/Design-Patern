﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace assignment1
{
    public class Computer
    {
        public Computer(IHardDisk disk, IProcessor processor, IMonitor monitor)
        {
            Disk = disk;
            Processor = processor;
            Monitor = monitor;
        }

        public IHardDisk Disk { get; set; }
        public IProcessor Processor { get; set; }
        public IMonitor Monitor { get; set; }

        public void Test()
        {
            Processor.PerformAction();
            Disk.StoreData();
            Monitor.Display();
        }
    }
}
