﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace assignment1
{
    public abstract class ComputerShop
    {
        public Computer CreateComputer()
        {
            IProcessor processor = NewProcessor();
            IHardDisk disk = NewDisk();
            IMonitor monitor = NewMonitor();

            Computer computer = new Computer(disk, processor, monitor);
            return computer;
        }
        public abstract IHardDisk NewDisk();
        public abstract IProcessor NewProcessor();
        public abstract IMonitor NewMonitor();
    }
}
