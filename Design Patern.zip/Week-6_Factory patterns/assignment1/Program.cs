﻿namespace assignment1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Program program = new Program();    
            program.Start();
        }

        private void Start()
        {
            Console.WriteLine("[shop creating expensive computers]");
            ExpensiveStore expensive = new ExpensiveStore();
            Computer expensiveComputer = expensive.CreateComputer();
            expensiveComputer.Test();
            Console.WriteLine();

            Console.WriteLine("[shop creating cheap computers]");
            CheapStore cheap = new CheapStore();
            Computer cheapComputer = cheap.CreateComputer();
            cheapComputer.Test();
        }
    }
}