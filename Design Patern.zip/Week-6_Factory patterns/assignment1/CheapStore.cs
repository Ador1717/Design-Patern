﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace assignment1
{
    public class CheapStore : ComputerShop
    {
        public override IProcessor NewProcessor()
        {
            return new CheapProcessor();
        }
        public override IHardDisk NewDisk()
        {
            return new CheapHardDisk();
        }
        public override IMonitor NewMonitor()
        {
            return new CheapMonitor();
        }
    }
}
